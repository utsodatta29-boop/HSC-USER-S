# HSC Course Hub — বাংলা সেটআপ

এই অ্যাপটি তোমার Supabase `UAAC` project-এর সাথে যুক্ত। এতে Student login/signup, course catalog, admin course creation, resumable video upload, manual bKash/Nagad/Rocket payment review এবং approved হলে course access আছে।

## GitHub-এ প্রকাশ
1. ZIP Extract করো।
2. সব ফাইল (`index.html`, `manifest.webmanifest`, `sw.js`, `icons/`, `README_BN.md`) repository-এর root-এ upload করো।
3. GitHub → Settings → Pages → Deploy from a branch → `main` → `/(root)` → Save।
4. কয়েক মিনিট পরে GitHub Pages HTTPS URL খুলো। Android Chrome-এর ⋮ menu থেকে Install app বেছে নাও।

## তোমার অ্যাকাউন্টকে Admin বানানো
1. সাইটে নিজের email দিয়ে Sign up করো; দরকার হলে email verify করে Login করো।
2. Supabase Dashboard → SQL Editor → New query খুলো।
3. নিচের SQL-এ `you@example.com`-এর জায়গায় ঠিক সেই email বসিয়ে Run করো:

   `update public.profiles set is_admin = true where lower(email) = lower('you@example.com');`

4. সাইট refresh বা logout/login করো। Admin Studio দেখা যাবে।
5. Admin Studio থেকে course তৈরি করো, তারপর video upload করো। কোর্স তৈরি করার সময় Published tick দিলে public catalog-এ দেখা যাবে; পরে Draft থেকেও Publish করা যাবে।

## পেমেন্ট
- শিক্ষার্থী bKash/Nagad/Rocket-এ টাকা পাঠিয়ে Transaction ID জমা দেবে।
- Admin Studio → Payment review-এ নিজের merchant app-এ transaction যাচাই করে Approve বা Reject করবে।
- Approve করলে enrollment স্বয়ংক্রিয়ভাবে তৈরি হবে।
- এটি **manual verification**। Auto payment confirmation-এর জন্য official merchant gateway integration ও server-side verification লাগবে। Payment number এই starter-এ configure করা নেই; শিক্ষার্থীদের কাছে নিরাপদভাবে আলাদা করে জানাতে হবে।

## নিরাপত্তা ও সীমাবদ্ধতা
- Frontend-এ শুধু Supabase publishable key আছে। `service_role` key কখনো GitHub-এ দেবে না।
- ভিডিও private Storage-এ থাকে; signed URL ৩০ মিনিটের জন্য তৈরি হয়। স্ক্রিন রেকর্ডিং পুরোপুরি ঠেকানো যায় না।
- Storage quota, bandwidth ও খরচ Supabase plan-এর ওপর নির্ভরশীল। Bucket-এর 2GB file limit plan quota বাড়ায় না।
- শুধু নিজের বা বিক্রির অনুমতি আছে এমন ভিডিও আপলোড করবে।
